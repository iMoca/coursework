#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(dplyr)
library(tseries)
library(forecast)
library(ggplot2)
library(stats)
library(lubridate)
library(tidyr)
library(NlinTS)
library(vars)
library(tsbox)
library(tidyverse)


options(expressions=10000)


combine_df = read.csv(url("https://raw.githubusercontent.com/iMoca/coursework/master/combine_df.csv"))
coef = read.csv(url("https://raw.githubusercontent.com/iMoca/coursework/master/coef.csv"))
#combine_df <- read.csv("C:/Users/Nik Jarvis/Desktop/ioana/Assignment3/combine_df.csv")
#coef <- read.csv("C:/Users/Nik Jarvis/Desktop/ioana/Assignment3/coef.csv")



#specifying the function that will turn our data into a time series once it's adjusted, to be applied to rv$df_data (a)
timeseries <- function(x) {
    tsco2 <-ts(x[, c('co2')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
    tssf6 <-ts(x[, c('sf6')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
    tsn2o <-ts(x[, c('n2o')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
    tsch4 <-ts(x[, c('ch4')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
    temptrend <-ts(x[, c('temp')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
    assign("temptrend",temptrend,envir=.GlobalEnv)  
    multiplets <- ts_c(temptrend, tsch4, tsco2, tsn2o, tssf6)
    multiplets <- window(multiplets, start=c(1997, 7), end=c(2012,1))
    assign("multiplets",multiplets,envir=.GlobalEnv)  
    VARobject <- VAR(multiplets, p=3, type = "both")
    assign("VARobject",VARobject,envir=.GlobalEnv)  
    fcast_for_plot <- forecast::forecast(VARobject, h=50)
    assign("fcast_for_plot",fcast_for_plot,envir=.GlobalEnv)
    return(fcast_for_plot)
}


timeseries2 <- function(x) {
    tsnewtemp <- ts(x[, c('temp')], start=c(1997,7), end=c(2012,1),frequency=12)
    newtempforecast <- predict(tsnewtemp)
    assign("newtempforecast",newtempforecast,envir=.GlobalEnv)  # put it in the global env
    return(newtempforecast)
}



ui <- fluidPage(
    pageWithSidebar(
        
        headerPanel("Greenhouse gas concentration and impact on Canadian Ground Temperature"),
        
        sidebarPanel(
            # Slider input for co2 change
            sliderInput("slider1", "Carbon dioxide (CO2) concentration percent change:",
                        min = 10, max = 200, value = 100),
            
            # Slider input for sf6 change
            sliderInput("slider2", "Sulfur hexafluoride (SF6) concentration percent change:",
                        min = 10, max = 200, value = 100),
            
            
            # Slider input for N2O change
            sliderInput("slider3", "Nitrous oxide (N2O) concentration percent change:",
                        min = 10, max = 200, value = 100),
            
            
            # Slider input for ch4 change
            sliderInput("slider4", "Methane (CH4) concentration percent change:",
                        min = 10, max = 200, value = 100),
            
            actionButton("go","Predict")
        ),
        
        mainPanel(
            plotOutput("varplot"),
            plotOutput("tempplot"),
            tableOutput("predtable")
        )
    )
)


server <- function(input, output, session) {
 
    #specifying a reactive dataset that is currently empty, but will be populated by our dataframe
    rv = reactiveValues(df_data = NULL)
    rv$df_data = combine_df

    #Creating reactive variables based on user inputs, as percentages
    inp1 <- reactive ({(as.numeric(input$slider1))/100})
    inp2 <- reactive ({(as.numeric(input$slider2))/100})
    inp3 <- reactive ({(as.numeric(input$slider3))/100})
    inp4 <- reactive ({(as.numeric(input$slider4))/100})
   
    #Upon hitting predict, we recalculate the columns of our reactive data 
    observeEvent(input$go, {
        isolate({
            rv$df_data[,3] <- (combine_df[,3] * inp1())
            rv$df_data[,6] <- (combine_df[,6] * inp2())
            rv$df_data[,4] <- (combine_df[,4] * inp3())
            rv$df_data[,5] <- (combine_df[,5] * inp4())
            rv$df_data[,2] <- (as.numeric(as.matrix(rv$df_data[3:6]) %*% as.matrix(coef$'fit.coefficients'[2:5]) - 97.05746141))
            assign("rv$df_data",rv$df_data,envir=.GlobalEnv)

        })
    })    
   
        
        a <- reactive ({timeseries(rv$df_data)})
        b <- reactive ({timeseries2(rv$df_data)})
    
        repeatableplot <- reactive ({plot(a(), main="Initial forecast and updated values", xlab="Year")})
        repeatableplot2 <- reactive ({plot(b(), main="Estimates of Temperature Updated Trend", xlab="Year")})
        repeatabletable <- reactive ({b()}) 
    
        output$varplot <- renderPlot({repeatableplot()})
        output$tempplot <- renderPlot({repeatableplot2()})
        output$predtable <- renderTable({repeatabletable()})  
    
    }  
    


shinyApp(ui, server)
