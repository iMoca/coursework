library(dplyr)
library(tseries)
library(forecast)
library(ggplot2)
library(stats)
library(lubridate)
library(tidyr)
library(NlinTS)
library(vars)
library(tsbox)


#climate_data = read.csv(url("https://raw.githubusercontent.com/iMoca/coursework/master/GlobalLandTemperaturesByCountry.csv"))
climate_data = read.csv("C:/Users/Nik Jarvis/Desktop/ioana/climate-change-earth-surface-temperature-data/GlobalLandTemperaturesByCountry.csv")
climate_data1<-climate_data[-3]
canada_climate<-climate_data1[climate_data1$Country=="Canada",]
canada_climate <- plyr::rename(canada_climate, c(AverageTemperature="ave_temp", Country = "Country"))
canada_climate$dt = as.Date(canada_climate$dt)
canada_climate<-na.omit(canada_climate)

#Generating a time series and extracting the trend
tsclimate <- ts(canada_climate[, c('ave_temp')], start=c(1993, 1),end=c(2013, 9),frequency = 12)
decompose_canadaclimate = decompose(tsclimate, "multiplicative")
temperature_trend <- window(decompose_canadaclimate$trend, start=c(1993, 1), end=c(2013, 1))
tstrend <- decompose_canadaclimate$trend
trenddf <- ts_df(tstrend)
trenddf <- plyr::rename(trenddf , c(time="dt"))
trenddf <- plyr::rename(trenddf , c(value="temp"))

#Reading and preparing GHG data
co2dat<- read.table(url("ftp://aftp.cmdl.noaa.gov/data/trace_gases/co2/flask/surface/co2_alt_surface-flask_1_ccgg_month.txt"), header=FALSE, quote="\"")
colnames(co2dat) <- c("site", "year", "month", "co2")
co2dat <- co2dat %>% 
  mutate(dt = make_datetime(year, month)) 


sf6dat<-read.table(url("ftp://aftp.cmdl.noaa.gov/data/trace_gases/sf6/flask/surface/sf6_alt_surface-flask_1_ccgg_month.txt"), header=FALSE, quote="\"")
colnames(sf6dat) <- c("site", "year", "month", "sf6")
sf6dat <- sf6dat %>%
  mutate(dt = make_datetime(year, month)) 

n2odat<-read.table(url("ftp://aftp.cmdl.noaa.gov/data/trace_gases/n2o/flask/surface/n2o_alt_surface-flask_1_ccgg_month.txt"), header=FALSE, quote="\"")
colnames(n2odat) <- c("site", "year", "month", "n2o")
n2odat <- n2odat %>%
  mutate(dt = make_datetime(year, month)) 


ch4dat<-read.table(url("ftp://aftp.cmdl.noaa.gov/data/trace_gases/ch4/flask/surface/ch4_alt_surface-flask_1_ccgg_month.txt"), header=FALSE, quote="\"")
colnames(ch4dat) <- c("site", "year", "month", "ch4")
ch4dat <- ch4dat %>%
  mutate(dt = make_datetime(year, month)) 

#cleaning GHG data 
co2dat$dt <- as.Date(co2dat$dt)
n2odat$dt <- as.Date(n2odat$dt)
ch4dat$dt <- as.Date(ch4dat$dt)
sf6dat$dt <- as.Date(sf6dat$dt)



#Initial pass at time series modeling, no adjustments
temperature_trend <- window(decompose_canadaclimate$trend, start=c(1997, 7), end=c(2012, 1))

tsco2 <- ts(co2dat[, c('co2')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tssf6 <- ts(sf6dat[, c('sf6')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tsn2o <- ts(n2odat[, c('n2o')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tsch4 <- ts(ch4dat[, c('ch4')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
trend <- decompose_canadaclimate$trend
multiplets <- ts_c(trend, tsch4, tsco2, tsn2o, tssf6)
multiplets <- window(multiplets, start=c(1997, 7), end=c(2012,1))
VAR_Lag1 <- VAR(multiplets, p=3, type = "both")
forecast1 <- forecast(VAR_Lag1, h=50)

#Merging with trend data
combine_df <- merge(trenddf, co2dat, by="dt")
combine_df <- merge(combine_df, n2odat, by="dt")
combine_df <- merge(combine_df, ch4dat, by="dt")
combine_df <- merge(combine_df, sf6dat, by="dt")
cols <- c(1,2,6,10,14,18)
combine_df <- combine_df[,cols]
combine_df$'(Intercept)' <- numeric(nrow(combine_df))
combine_df$'(Intercept)'<- 1

#combine_df <- combine_df[2:7]
write.csv(combine_df,'combine_df.csv', row.names=FALSE)

#Generating coefficients
fit <- lm (temp ~ co2 + n2o + ch4 + sf6 , data = combine_df)
coef <- as.data.frame(fit$'coefficients')
write.csv(coef,'coef.csv', row.names=FALSE)

str(coef)

#Adjusting the original data
combine_df2 <- combine_df %>%
  mutate(co2 = co2 * 10/100)%>%
  mutate(sf6 = sf6 * 10/100) %>%
  mutate(n2o = n2o * 10/100) %>%
  mutate(ch4 = ch4 * 10/100) 


#check if we can multiply the matrices
coef = coef[,-1]
coefmat <-as.matrix(coef$'fit$coefficients'[2:5])
dim(coefmat)

dfmat <- as.matrix(combine_df2[3:7])
dim(dfmat)


#combine_df2 <- combine_df2[2:6]
write.csv(combine_df2,'combine_df2.csv', row.names=FALSE)
combine_df2$temp <- as.numeric(as.matrix(combine_df2[3:6]) %*% as.matrix(coef$'fit.coefficients'[2:5]) - 97.05746141)


#Forecasting with adjusted data
tsco2_2 <- ts(combine_df2[, c('co2')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tssf6_2 <- ts(combine_df2[, c('sf6')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tsn2o_2 <- ts(combine_df2[, c('n2o')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
tsch4_2 <- ts(combine_df2[, c('ch4')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
trend_2 <- ts(combine_df2[, c('temp')], start=c(1997, 7),end=c(2012, 1),frequency = 12)
multiplets_2 <- ts_c(trend_2, tsch4_2, tsco2_2, tsn2o_2, tssf6_2)
multiplets_2 <- window(multiplets_2, start=c(1997, 7), end=c(2012,1))
VAR_Lag2 <- VAR(multiplets_2, p=3, type = "both")
forecast2 <- forecast(VAR_Lag2, h=50)



#Plots for comparison
plot(forecast1, xlab="Year")
plot(forecast2, xlab="Year")


